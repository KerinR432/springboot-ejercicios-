package goya.daw2.pruebas_plantillas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormulariosEncadenadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
