# Resumen rapido para examen de Spring Boot

Apunte de repaso basado en los ejercicios de este workspace: formularios con Thymeleaf, sesiones, cookies, validacion, JPA/MySQL y API REST.

## 1. Mapa mental rapido

Spring Boot suele caer en examen en 2 modelos:

### A. Aplicacion web MVC

Peticion del navegador -> `@Controller` -> `Model` -> plantilla Thymeleaf -> HTML

### B. API REST

Peticion HTTP -> `@RestController` -> servicio -> repositorio -> base de datos -> JSON

Idea clave:

- `@Controller` devuelve vistas.
- `@RestController` devuelve datos.
- `Model` sirve para pasar datos a HTML.
- `ResponseEntity` sirve para controlar codigo HTTP y respuesta.

## 2. Estructura que debes recordar

```text
src/main/java                -> clases Java
src/main/resources/templates -> vistas Thymeleaf
src/main/resources/static    -> css, js, imagenes
src/main/resources/application.properties -> configuracion
```

## 3. Anotaciones que mas entran

| Anotacion | Para que sirve | Donde se usa |
|---|---|---|
| `@SpringBootApplication` | arranca la app | clase principal |
| `@Controller` | controlador web MVC | devolver HTML |
| `@RestController` | controlador REST | devolver JSON |
| `@GetMapping` | atender GET | mostrar pagina o listar |
| `@PostMapping` | atender POST | guardar datos |
| `@PutMapping` | actualizar | API REST |
| `@DeleteMapping` | borrar | API REST |
| `@RequestMapping` | prefijo de rutas | clase o metodo |
| `@RequestParam` | leer parametro de formulario o URL | MVC |
| `@PathVariable` | leer parametro en la ruta | REST |
| `@ModelAttribute` | enlazar formulario con objeto | MVC |
| `@RequestBody` | convertir JSON a objeto | REST |
| `@Valid` | activar validacion | controlador |
| `BindingResult` | ver errores de validacion | justo despues de `@Valid` |
| `@Entity` | clase persistente | JPA |
| `@Id` | clave primaria | entidad |
| `@GeneratedValue` | autogenerar id | entidad |
| `@Repository` | acceso a datos | repositorio |
| `@Service` | logica de negocio | servicio |

## 4. Diferencia clave: MVC vs REST

| Caso | Devuelve | Se suele usar |
|---|---|---|
| `@Controller` | nombre de plantilla, por ejemplo `"login"` | `Model`, formularios, Thymeleaf |
| `@RestController` | objeto, lista o `ResponseEntity` | JSON, CRUD, clientes HTTP |

Regla corta:

- Si el usuario va a ver una pagina HTML, piensa en `@Controller`.
- Si el cliente va a consumir datos, piensa en `@RestController`.

## 5. Patron tipico de formulario con Thymeleaf

### Controlador

```java
@GetMapping("/formulario")
public String mostrarFormulario(Model modelo) {
    modelo.addAttribute("persona", new Persona());
    return "formulario";
}

@PostMapping("/resultados")
public String procesar(@ModelAttribute Persona persona, Model modelo) {
    modelo.addAttribute("persona", persona);
    return "resultados";
}
```

### HTML con Thymeleaf

```html
<form th:action="@{/resultados}" th:object="${persona}" method="post">
  <input type="text" th:field="*{nombre}">
  <button type="submit">Enviar</button>
</form>
```

### Que hace cada cosa

- `th:action` indica a que ruta envia el formulario.
- `th:object` enlaza el formulario con un objeto.
- `th:field` enlaza cada input con un atributo del objeto.
- `@ModelAttribute` rellena el objeto automaticamente con los datos enviados.
- `Model` manda datos desde el controlador a la vista.

## 6. Thymeleaf: chuleta express

| Sintaxis | Uso |
|---|---|
| `th:text="${nombre}"` | mostrar valor |
| `th:if="${condicion}"` | mostrar si se cumple |
| `th:each="p : ${personas}"` | recorrer listas |
| `th:value="${dato}"` | rellenar value |
| `th:href="@{/ruta}"` | enlaces |
| `th:action="@{/ruta}"` | accion de formulario |
| `th:object="${objeto}"` | objeto del formulario |
| `th:field="*{campo}"` | campo enlazado |

## 7. Validacion: muy preguntable

### En la clase

```java
public class Persona {
    @NotNull
    @Size(min = 2, max = 30)
    private String nombre;

    @NotNull
    private Integer edad;
}
```

### En el controlador

```java
@PostMapping("/guardar")
public String guardar(@Valid Persona persona, BindingResult br, Model modelo) {
    if (br.hasErrors()) {
        return "formulario";
    }
    modelo.addAttribute("persona", persona);
    return "resultado";
}
```

### Reglas de oro

- `BindingResult` tiene que ir justo despues del objeto con `@Valid`.
- Si hay errores, normalmente se vuelve al mismo formulario.
- `@NotNull` comprueba que no sea `null`.
- `@NotBlank` comprueba que el texto no este vacio ni solo espacios.
- `@Size(min, max)` limita longitud.

## 8. `@RequestParam`, `@PathVariable`, `@ModelAttribute`, `@RequestBody`

| Anotacion | De donde saca el dato | Ejemplo |
|---|---|---|
| `@RequestParam` | query string o input suelto | `?id=4` |
| `@PathVariable` | parte de la URL | `/peliculas/4` |
| `@ModelAttribute` | formulario completo | formulario HTML |
| `@RequestBody` | cuerpo JSON | API REST |

Ejemplos rapidos:

```java
public String buscar(@RequestParam String nombre)
public Pelicula ver(@PathVariable Long id)
public String guardar(@ModelAttribute Persona persona)
public ResponseEntity<?> crear(@RequestBody Pelicula pelicula)
```

## 9. Sesiones

La sesion guarda datos en el servidor entre peticiones del mismo usuario.

Se usa mucho para:

- login
- pasos de formularios encadenados
- carrito
- guardar progreso temporal

Ejemplo:

```java
@PostMapping("/login")
public String login(@RequestParam String usuario, HttpSession sesion) {
    sesion.setAttribute("usuario", usuario);
    return "redirect:/perfil";
}

@GetMapping("/perfil")
public String perfil(HttpSession sesion, Model modelo) {
    String usuario = (String) sesion.getAttribute("usuario");
    if (usuario == null) {
        return "redirect:/login";
    }
    modelo.addAttribute("usuario", usuario);
    return "perfil";
}
```

Metodos importantes:

- `setAttribute(clave, valor)` guarda
- `getAttribute(clave)` recupera
- `removeAttribute(clave)` elimina un dato
- `invalidate()` cierra toda la sesion

## 10. Cookies

La cookie guarda datos en el navegador del cliente.

Diferencia clave con sesion:

- sesion = lado servidor
- cookie = lado cliente

Crear cookie:

```java
Cookie cookie = new Cookie("usuario", usuario);
cookie.setMaxAge(3600);
cookie.setPath("/");
response.addCookie(cookie);
```

Leer cookie:

```java
public String perfil(@CookieValue(value = "usuario", defaultValue = "") String usuario) {
    if (usuario.isEmpty()) {
        return "redirect:/login";
    }
    return "perfil";
}
```

Cuando te pregunten diferencias:

- la sesion es mas segura para datos internos
- la cookie permanece en el navegador hasta que caduque o se borre
- la cookie viaja en cada peticion HTTP

## 11. `redirect:` vs devolver vista

Muy importante en examen:

- `return "login";` -> renderiza `login.html`
- `return "redirect:/login";` -> hace otra peticion a `/login`

Se usa `redirect:` cuando:

- quieres cambiar de ruta tras un POST
- quieres evitar reenviar formulario al refrescar
- quieres proteger acceso si no hay login

## 12. JPA y base de datos

### Entidad minima

```java
@Entity
public class Pelicula {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String nombre;
    private String director;
}
```

### Repositorio minimo

```java
public interface RepositorioPelicula extends CrudRepository<Pelicula, Long> {
    boolean existsByNombre(String nombre);
}
```

### Servicio minimo

```java
@Service
public class ServicioPelicula {
    private final RepositorioPelicula repo;

    public ServicioPelicula(RepositorioPelicula repo) {
        this.repo = repo;
    }

    public List<Pelicula> listar() {
        return (List<Pelicula>) repo.findAll();
    }
}
```

### Metodos CRUD que debes conocer

- `save(objeto)` guarda o actualiza
- `findById(id)` busca uno
- `findAll()` lista todos
- `delete(objeto)` borra
- `existsBy...()` comprueba existencia

## 13. `application.properties` que suele caer

Ejemplo tipico con MySQL:

```properties
spring.application.name=miapp
spring.jpa.hibernate.ddl-auto=update
spring.datasource.url=jdbc:mysql://localhost:3306/mibd
spring.datasource.username=usuario
spring.datasource.password=clave
spring.jpa.show-sql=true
```

Que significa:

- `ddl-auto=update` actualiza tablas segun entidades
- `datasource.url` indica a que base conectarse
- `username/password` credenciales
- `show-sql=true` muestra consultas SQL por consola

## 14. API REST: estructura mental

### Controlador REST basico

```java
@RestController
@RequestMapping("/peliculas")
public class ControladorPelicula {

    @GetMapping
    public ResponseEntity<List<Pelicula>> listar() {
        return ResponseEntity.ok(servicio.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pelicula> ver(@PathVariable Long id) {
        return ResponseEntity.ok(servicio.buscar(id));
    }

    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Pelicula pelicula) {
        Pelicula guardada = servicio.guardar(pelicula);
        URI location = URI.create("/peliculas/" + guardada.getId());
        return ResponseEntity.created(location).build();
    }
}
```

### Respuestas HTTP que debes asociar

- `200 OK` -> lectura correcta
- `201 Created` -> creado correctamente
- `400 Bad Request` -> datos invalidos
- `404 Not Found` -> recurso no existe
- `204 No Content` -> borrado correcto sin cuerpo

## 15. Flujo normal en una app con capas

```text
Controller -> Service -> Repository -> Database
```

Funcion de cada capa:

- `Controller`: recibe peticiones y prepara respuesta
- `Service`: logica de negocio
- `Repository`: acceso a datos
- `Entity`: modelo persistente

## 16. Errores tipicos que penalizan mucho

- devolver un nombre de vista que no coincide con el HTML
- poner `BindingResult` en mala posicion
- usar `@Controller` cuando querias devolver JSON
- usar `@RestController` cuando querias cargar una vista
- olvidar getters y setters, y entonces no enlaza el formulario
- olvidar `@Id` en una entidad
- no controlar `null` o `Optional` al buscar por id
- usar `return "perfil"` cuando en realidad necesitas `redirect:/perfil`
- confundir cookie con sesion
- no poner `method="post"` en el formulario

## 17. Respuestas cortas de teoria para escribir en examen

### Que es Spring Boot

Framework que simplifica la creacion de aplicaciones Java, especialmente web y REST, reduciendo configuracion y aportando auto-configuracion.

### Que es Thymeleaf

Motor de plantillas del lado servidor que permite generar HTML dinamico a partir de datos enviados desde Spring.

### Que es JPA

Especificacion para mapear objetos Java a tablas de base de datos y trabajar con persistencia mediante entidades y repositorios.

### Diferencia entre cookie y sesion

La sesion guarda datos en el servidor para un usuario concreto; la cookie guarda datos en el navegador del cliente.

### Para que sirve `ResponseEntity`

Permite controlar el cuerpo, cabeceras y codigo HTTP de la respuesta en una API REST.

## 18. Plantillas mentales segun tipo de ejercicio

### Si te piden formulario MVC

1. clase modelo con atributos
2. `@GetMapping` para mostrar formulario
3. `Model.addAttribute(...)`
4. HTML con `th:object` y `th:field`
5. `@PostMapping` para recoger datos
6. devolver vista de resultado o `redirect:`

### Si te piden login con sesion

1. formulario login
2. POST recibe usuario
3. guardar en `HttpSession`
4. rutas privadas comprueban sesion
5. logout con `invalidate()`

### Si te piden login con cookies

1. POST crea `Cookie`
2. `response.addCookie(cookie)`
3. otras rutas leen con `@CookieValue`
4. si no existe cookie, `redirect:/login`

### Si te piden CRUD REST

1. entidad `@Entity`
2. repositorio `CrudRepository`
3. servicio
4. `@RestController`
5. endpoints GET, POST, PUT, DELETE
6. `ResponseEntity` con codigos correctos

## 19. Checklist final antes de entregar un ejercicio

- la ruta del formulario coincide con el `@PostMapping`
- el nombre devuelto por el controlador coincide con la plantilla
- el objeto del formulario tiene getters y setters
- si hay validacion, `@Valid` y `BindingResult` estan bien puestos
- si hay base de datos, la entidad tiene `@Entity` y `@Id`
- si es REST, has usado `@RequestBody` y `@PathVariable` cuando toca
- si es login o multi-paso, sabes si usar sesion o cookie
- si rediriges, usas `redirect:/ruta`

## 20. Ultimo repaso de 2 minutos

Memoriza estas asociaciones:

- HTML -> `@Controller`
- JSON -> `@RestController`
- formulario completo -> `@ModelAttribute`
- JSON recibido -> `@RequestBody`
- dato en URL -> `@PathVariable`
- dato en query o input simple -> `@RequestParam`
- persistencia -> `@Entity` + `CrudRepository`
- validacion -> `@Valid` + `BindingResult`
- guardar usuario temporal -> `HttpSession`
- guardar dato en navegador -> `Cookie`

Si en examen te bloqueas, piensa siempre en este orden:

1. que entra en la peticion
2. quien la recibe
3. donde se guarda o procesa
4. que se devuelve: vista o JSON
