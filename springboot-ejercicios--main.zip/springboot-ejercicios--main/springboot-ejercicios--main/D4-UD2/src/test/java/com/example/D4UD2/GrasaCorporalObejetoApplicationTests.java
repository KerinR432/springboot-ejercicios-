package com.example.D4UD2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrasaCorporalObejetoApplicationTests {

	@Test
	void contextLoads() {
	}

}
