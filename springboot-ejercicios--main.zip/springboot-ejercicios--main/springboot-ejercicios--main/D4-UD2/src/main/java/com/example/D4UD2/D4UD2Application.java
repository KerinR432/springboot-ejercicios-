package com.example.D4UD2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class D4UD2Application {

	public static void main(String[] args) {
		SpringApplication.run(D4UD2Application.class, args);
	}

}
